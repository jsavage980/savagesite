//CSS animations
$(function (){
		$('.about').removeClass("hidden").viewportChecker({
	    classToAdd: 'visible animated fadeInDown', // add to the elements when they are visible
		offset: 100
	   });
	   $('.fa-arrow-circle-down').removeClass("hidden").viewportChecker({
	    classToAdd: 'visible animated rotateIn', // add to the elements when they are visible
	    offset: 100
	   });
	   $('.about-title, .content-work').removeClass("hidden").viewportChecker({
	    classToAdd: 'visible animated bounceInLeft', // add to the elements when they are visible
	    offset: 100   
	   });
	  $('.statement, .post').removeClass("hidden").viewportChecker({
	      classToAdd: 'visible animated fadeInUp', // add to the elements when they are visible
		  offset: 100
	   });
	    $('.fa-anchor').removeClass("hidden").viewportChecker({
	      classToAdd: 'visible animated swing', // add to the elements when they are visible
		  offset: 100
	   }); 
	   $('.fa-camera-retro').removeClass("hidden").viewportChecker({
	      classToAdd: 'visible animated flash', // add to the elements when they are visible
		  offset: 100
	   }); 
	   $('.fa-rocket').removeClass("hidden").viewportChecker({
	      classToAdd: 'visible animated zoomOutUp', // add to the elements when they are visible
		  offset: 100
	   }); 
	   $('.fa-thumbs-up').removeClass("hidden").viewportChecker({
	      classToAdd: 'visible animated wobble', //add to the elements when they are visible
		  offset: 100
	   }); 
});   

//page scroll
$(function() {
    $('ul.nav a').bind('click',function(event){
        var $anchor = $(this);
 
        $('html, body').stop().animate({
            scrollTop: $($anchor.attr('href')).offset().top
        }, 1500,'easeInOutExpo');
        event.preventDefault();
    });
});

//close navbar collaspe when nav link is clicked
$('.navbar-nav a').click(function() {
    var navbar_toggle = $('.navbar-toggle');
    if (navbar_toggle.is(':visible')) {
        navbar_toggle.trigger('click');
    }
});

// get hovers on touch, so behaves more like :hover and less like :active on mobile    
$('body').bind('touchstart', function() {}); 

//calendar
    $.get("calendar.xml", function (data) {

        var date1 = $(data).find("august").find("event1").find("date").text();
        var date2 = $(data).find("august").find("event2").find("date").text();
        var date3 = $(data).find("august").find("event3").find("date").text();
        var month = $(data).find("august").find("month").text();
        $("#date1").html(date1);
        $("#date2").html(date2);
        $("#date3").html(date3);
        $("#month").html(month);

        //store the august node in a variable
        var locs1 = $(data).find("august").find("event1");
        var locs2 = $(data).find("august").find("event2");
        var locs3 = $(data).find("august").find("event3");
		var locs4 = $(data).find("august").find("event43");

        //START the <ul> list of locations 1
        var locList1 = "<ul>";

        //loop/iterate through nodes in the august xml
        $(locs1).find("location").each(function () {
            locList1 += "<li>" + $(this).text() + "</li>";
        });
        //end the </ul> list of box features
        locList1 += "</ul>";

        //and put the whole list in the loc HTML container
        $("#loc1").html(locList1);

        //START the <ul> list of locations 2
        var locList2 = "<ul>";

        //loop/iterate through nodes in the august xml
        $(locs2).find("location").each(function () {
            locList2 += "<li>" + $(this).text() + "</li>";
        });
        //end the </ul> list of box features
        locList2 += "</ul>";

        //and put the whole list in the loc HTML container
        $("#loc2").html(locList2);

        //START the <ul> list of locations 3
        var locList3 = "<ul>";

        //loop/iterate through nodes in the august xml
        $(locs3).find("location").each(function () {
            locList3 += "<li>" + $(this).text() + "</li>";
        });
        //end the </ul> list of box features
        locList3 += "</ul>";

        //and put the whole list in the loc HTML container
        $("#loc3").html(locList3);




        //AUGUST
        $('#augustBtn').click(function () {
            var date1 = $(data).find("august").find("event1").find("date").text();
            var date2 = $(data).find("august").find("event2").find("date").text();
            var date3 = $(data).find("august").find("event3").find("date").text();
            var month = $(data).find("august").find("month").text();
            $("#date1").html(date1);
            $("#date2").html(date2);
            $("#date3").html(date3);
            $("#month").html(month);

            //store the august node in a variable
            var locs1 = $(data).find("august").find("event1");
            var locs2 = $(data).find("august").find("event2");
            var locs3 = $(data).find("august").find("event3");

            //START the <ul> list of locations 1
            var locList1 = "<ul>";

            //loop/iterate through nodes in the august xml
            $(locs1).find("location").each(function () {
                locList1 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList1 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc1").html(locList1);

            //START the <ul> list of locations 2
            var locList2 = "<ul>";

            //loop/iterate through nodes in the august xml
            $(locs2).find("location").each(function () {
                locList2 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList2 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc2").html(locList2);

            //START the <ul> list of locations 3
            var locList3 = "<ul>";

            //loop/iterate through nodes in the august xml
            $(locs3).find("location").each(function () {
                locList3 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList3 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc3").html(locList3);
        });
        //END AUGUST
        //SEPTEMBER
        $('#septBtn').click(function () {
            var date1 = $(data).find("september").find("event1").find("date").text();
            var date2 = $(data).find("september").find("event2").find("date").text();
            var date3 = $(data).find("september").find("event3").find("date").text();
            var month = $(data).find("september").find("month").text();
            $("#date1").html(date1);
            $("#date2").html(date2);
            $("#date3").html(date3);
            $("#month").html(month);

            //store the august node in a variable
            var locs1 = $(data).find("september").find("event1");
            var locs2 = $(data).find("september").find("event2");
            var locs3 = $(data).find("september").find("event3");

            //START the <ul> list of locations 1
            var locList1 = "<ul>";

            //loop/iterate through nodes in the september xml
            $(locs1).find("location").each(function () {
                locList1 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList1 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc1").html(locList1);

            //START the <ul> list of locations 2
            var locList2 = "<ul>";

            //loop/iterate through nodes in the september xml
            $(locs2).find("location").each(function () {
                locList2 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList2 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc2").html(locList2);

            //START the <ul> list of locations 3
            var locList3 = "<ul>";

            //loop/iterate through nodes in the september xml
            $(locs3).find("location").each(function () {
                locList3 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList3 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc3").html(locList3);
        });

        //END SEPTEMBER
        //OCTOBER
        $('#octBtn').click(function () {
            var date1 = $(data).find("october").find("event1").find("date").text();
            var date2 = $(data).find("october").find("event2").find("date").text();
            var date3 = $(data).find("october").find("event3").find("date").text();
            var month = $(data).find("october").find("month").text();
            $("#date1").html(date1);
            $("#date2").html(date2);
            $("#date3").html(date3);
            $("#month").html(month);

            //store the august node in a variable
            var locs1 = $(data).find("october").find("event1");
            var locs2 = $(data).find("october").find("event2");
            var locs3 = $(data).find("october").find("event3");

            //START the <ul> list of locations 1
            var locList1 = "<ul>";

            //loop/iterate through nodes in the october xml
            $(locs1).find("location").each(function () {
                locList1 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList1 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc1").html(locList1);

            //START the <ul> list of locations 2
            var locList2 = "<ul>";

            //loop/iterate through nodes in the october xml
            $(locs2).find("location").each(function () {
                locList2 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList2 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc2").html(locList2);

            //START the <ul> list of locations 3
            var locList3 = "<ul>";

            //loop/iterate through nodes in the october xml
            $(locs3).find("location").each(function () {
                locList3 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList3 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc3").html(locList3);
        });
        //END OCTOBER

        //NOVEMBER
        $('#novBtn').click(function () {
            var date1 = $(data).find("november").find("event1").find("date").text();
            var date2 = $(data).find("november").find("event2").find("date").text();
            var date3 = $(data).find("november").find("event3").find("date").text();
            var month = $(data).find("november").find("month").text();
            $("#date1").html(date1);
            $("#date2").html(date2);
            $("#date3").html(date3);
            $("#month").html(month);

            //store the november node in a variable
            var locs1 = $(data).find("november").find("event1");
            var locs2 = $(data).find("november").find("event2");
            var locs3 = $(data).find("november").find("event3");

            //START the <ul> list of locations 1
            var locList1 = "<ul>";

            //loop/iterate through nodes in the november xml
            $(locs1).find("location").each(function () {
                locList1 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList1 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc1").html(locList1);

            //START the <ul> list of locations 2
            var locList2 = "<ul>";

            //loop/iterate through nodes in the november xml
            $(locs2).find("location").each(function () {
                locList2 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList2 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc2").html(locList2);

            //START the <ul> list of locations 3
            var locList3 = "<ul>";

            //loop/iterate through nodes in the november xml
            $(locs3).find("location").each(function () {
                locList3 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList3 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc3").html(locList3);
        });
        //END NOVEMBER
        //DECEMBER
        $('#decBtn').click(function () {
            var date1 = $(data).find("december").find("event1").find("date").text();
            var date2 = $(data).find("december").find("event2").find("date").text();
            var date3 = $(data).find("december").find("event3").find("date").text();
            var month = $(data).find("december").find("month").text();
            $("#date1").html(date1);
            $("#date2").html(date2);
            $("#date3").html(date3);
            $("#month").html(month);

            //store the december node in a variable
            var locs1 = $(data).find("december").find("event1");
            var locs2 = $(data).find("december").find("event2");
            var locs3 = $(data).find("december").find("event3");

            //START the <ul> list of locations 1
            var locList1 = "<ul>";

            //loop/iterate through nodes in the december xml
            $(locs1).find("location").each(function () {
                locList1 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList1 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc1").html(locList1);

            //START the <ul> list of locations 2
            var locList2 = "<ul>";

            //loop/iterate through nodes in the december xml
            $(locs2).find("location").each(function () {
                locList2 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList2 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc2").html(locList2);

            //START the <ul> list of locations 3
            var locList3 = "<ul>";

            //loop/iterate through nodes in the december xml
            $(locs3).find("location").each(function () {
                locList3 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList3 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc3").html(locList3);
        });
        //END DECEMBER
        //JANUARY
        $('#janBtn').click(function () {
            var date1 = $(data).find("january").find("event1").find("date").text();
            var date2 = $(data).find("january").find("event2").find("date").text();
            var date3 = $(data).find("january").find("event3").find("date").text();
            var month = $(data).find("january").find("month").text();
            $("#date1").html(date1);
            $("#date2").html(date2);
            $("#date3").html(date3);
            $("#month").html(month);

            //store the december node in a variable
            var locs1 = $(data).find("january").find("event1");
            var locs2 = $(data).find("january").find("event2");
            var locs3 = $(data).find("january").find("event3");

            //START the <ul> list of locations 1
            var locList1 = "<ul>";

            //loop/iterate through nodes in the january xml
            $(locs1).find("location").each(function () {
                locList1 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList1 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc1").html(locList1);

            //START the <ul> list of locations 2
            var locList2 = "<ul>";

            //loop/iterate through nodes in the january xml
            $(locs2).find("location").each(function () {
                locList2 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList2 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc2").html(locList2);

            //START the <ul> list of locations 3
            var locList3 = "<ul>";

            //loop/iterate through nodes in the january xml
            $(locs3).find("location").each(function () {
                locList3 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList3 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc3").html(locList3);
        });
        //END JANUARY
        //FEBRUARY
        $('#febBtn').click(function () {
            var date1 = $(data).find("february").find("event1").find("date").text();
            var date2 = $(data).find("february").find("event2").find("date").text();
            var date3 = $(data).find("february").find("event3").find("date").text();
            var month = $(data).find("february").find("month").text();
            $("#date1").html(date1);
            $("#date2").html(date2);
            $("#date3").html(date3);
            $("#month").html(month);

            //store the december node in a variable
            var locs1 = $(data).find("february").find("event1");
            var locs2 = $(data).find("february").find("event2");
            var locs3 = $(data).find("february").find("event3");

            //START the <ul> list of locations 1
            var locList1 = "<ul>";

            //loop/iterate through nodes in the february xml
            $(locs1).find("location").each(function () {
                locList1 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList1 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc1").html(locList1);

            //START the <ul> list of locations 2
            var locList2 = "<ul>";

            //loop/iterate through nodes in the february xml
            $(locs2).find("location").each(function () {
                locList2 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList2 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc2").html(locList2);

            //START the <ul> list of locations 3
            var locList3 = "<ul>";

            //loop/iterate through nodes in the february xml
            $(locs3).find("location").each(function () {
                locList3 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList3 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc3").html(locList3);
        });
        //END FEBRUARY
        //MARCH
        $('#marchBtn').click(function () {
            var date1 = $(data).find("march").find("event1").find("date").text();
            var date2 = $(data).find("march").find("event2").find("date").text();
            var date3 = $(data).find("march").find("event3").find("date").text();
            var month = $(data).find("march").find("month").text();
            $("#date1").html(date1);
            $("#date2").html(date2);
            $("#date3").html(date3);
            $("#month").html(month);

            //store the december node in a variable
            var locs1 = $(data).find("march").find("event1");
            var locs2 = $(data).find("march").find("event2");
            var locs3 = $(data).find("march").find("event3");

            //START the <ul> list of locations 1
            var locList1 = "<ul>";

            //loop/iterate through nodes in the march xml
            $(locs1).find("location").each(function () {
                locList1 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList1 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc1").html(locList1);

            //START the <ul> list of locations 2
            var locList2 = "<ul>";

            //loop/iterate through nodes in the march xml
            $(locs2).find("location").each(function () {
                locList2 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList2 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc2").html(locList2);

            //START the <ul> list of locations 3
            var locList3 = "<ul>";

            //loop/iterate through nodes in the march xml
            $(locs3).find("location").each(function () {
                locList3 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList3 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc3").html(locList3);
        });

        //END MARCH
        //APRIL
        $('#aprilBtn').click(function () {
            var date1 = $(data).find("april").find("event1").find("date").text();
            var date2 = $(data).find("april").find("event2").find("date").text();
            var date3 = $(data).find("april").find("event3").find("date").text();
            var month = $(data).find("april").find("month").text();
            $("#date1").html(date1);
            $("#date2").html(date2);
            $("#date3").html(date3);
            $("#month").html(month);

            //store the december node in a variable
            var locs1 = $(data).find("april").find("event1");
            var locs2 = $(data).find("april").find("event2");
            var locs3 = $(data).find("april").find("event3");

            //START the <ul> list of locations 1
            var locList1 = "<ul>";

            //loop/iterate through nodes in the april xml
            $(locs1).find("location").each(function () {
                locList1 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList1 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc1").html(locList1);

            //START the <ul> list of locations 2
            var locList2 = "<ul>";

            //loop/iterate through nodes in the april xml
            $(locs2).find("location").each(function () {
                locList2 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList2 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc2").html(locList2);

            //START the <ul> list of locations 3
            var locList3 = "<ul>";

            //loop/iterate through nodes in the april xml
            $(locs3).find("location").each(function () {
                locList3 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList3 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc3").html(locList3);
        });

        //END APRIL
        //MAY
        $('#mayBtn').click(function () {
            var date1 = $(data).find("may").find("event1").find("date").text();
            var date2 = $(data).find("may").find("event2").find("date").text();
            var date3 = $(data).find("may").find("event3").find("date").text();
            var month = $(data).find("may").find("month").text();
            $("#date1").html(date1);
            $("#date2").html(date2);
            $("#date3").html(date3);
            $("#month").html(month);

            //store the december node in a variable
            var locs1 = $(data).find("may").find("event1");
            var locs2 = $(data).find("may").find("event2");
            var locs3 = $(data).find("may").find("event3");

            //START the <ul> list of locations 1
            var locList1 = "<ul>";

            //loop/iterate through nodes in the may xml
            $(locs1).find("location").each(function () {
                locList1 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList1 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc1").html(locList1);

            //START the <ul> list of locations 2
            var locList2 = "<ul>";

            //loop/iterate through nodes in the may xml
            $(locs2).find("location").each(function () {
                locList2 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList2 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc2").html(locList2);

            //START the <ul> list of locations 3
            var locList3 = "<ul>";

            //loop/iterate through nodes in the may xml
            $(locs3).find("location").each(function () {
                locList3 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList3 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc3").html(locList3);
        });

        //END MAY
        //JUNE
        $('#juneBtn').click(function () {
            var date1 = $(data).find("june").find("event1").find("date").text();
            var date2 = $(data).find("june").find("event2").find("date").text();
            var date3 = $(data).find("june").find("event3").find("date").text();
            var month = $(data).find("june").find("month").text();
            $("#date1").html(date1);
            $("#date2").html(date2);
            $("#date3").html(date3);
            $("#month").html(month);

            //store the december node in a variable
            var locs1 = $(data).find("june").find("event1");
            var locs2 = $(data).find("june").find("event2");
            var locs3 = $(data).find("june").find("event3");

            //START the <ul> list of locations 1
            var locList1 = "<ul>";

            //loop/iterate through nodes in the june xml
            $(locs1).find("location").each(function () {
                locList1 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList1 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc1").html(locList1);

            //START the <ul> list of locations 2
            var locList2 = "<ul>";

            //loop/iterate through nodes in the june xml
            $(locs2).find("location").each(function () {
                locList2 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList2 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc2").html(locList2);

            //START the <ul> list of locations 3
            var locList3 = "<ul>";

            //loop/iterate through nodes in the june xml
            $(locs3).find("location").each(function () {
                locList3 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList3 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc3").html(locList3);
        });
        //END JUNE
        //JULY
        $('#julyBtn').click(function () {
            var date1 = $(data).find("july").find("event1").find("date").text();
            var date2 = $(data).find("july").find("event2").find("date").text();
            var date3 = $(data).find("july").find("event3").find("date").text();
            var month = $(data).find("july").find("month").text();
            $("#date1").html(date1);
            $("#date2").html(date2);
            $("#date3").html(date3);
            $("#month").html(month);

            //store the december node in a variable
            var locs1 = $(data).find("july").find("event1");
            var locs2 = $(data).find("july").find("event2");
            var locs3 = $(data).find("july").find("event3");

            //START the <ul> list of locations 1
            var locList1 = "<ul>";

            //loop/iterate through nodes in the july xml
            $(locs1).find("location").each(function () {
                locList1 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList1 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc1").html(locList1);

            //START the <ul> list of locations 2
            var locList2 = "<ul>";

            //loop/iterate through nodes in the july xml
            $(locs2).find("location").each(function () {
                locList2 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList2 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc2").html(locList2);

            //START the <ul> list of locations 3
            var locList3 = "<ul>";

            //loop/iterate through nodes in the july xml
            $(locs3).find("location").each(function () {
                locList3 += "<li>" + $(this).text() + "</li>";
            });
            //end the </ul> list of box features
            locList3 += "</ul>";

            //and put the whole list in the loc HTML container
            $("#loc3").html(locList3);
        });
        //END JULY

});   